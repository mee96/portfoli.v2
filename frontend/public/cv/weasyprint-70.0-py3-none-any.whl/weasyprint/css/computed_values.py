"""Convert specified property values into computed values."""

from functools import partial
from math import pi

from tinycss2.color5 import parse_color

from ..logger import LOGGER
from ..text.line_break import strut
from .functions import check_math
from .properties import INITIAL_VALUES, ZERO_PIXELS, Dimension
from .units import LENGTH_UNITS, to_pixels

# Value in pixels of font-size for <absolute-size> keywords: 12pt (16px) for
# medium, and scaling factors given in CSS3 for others:
# https://www.w3.org/TR/css-fonts-3/#font-size-prop
FONT_SIZE_KEYWORDS = {
    # medium is 16px, others are a ratio of medium
    name: INITIAL_VALUES['font_size'] * factor
    for name, factor in (
        ('xx-small', 3 / 5),
        ('x-small', 3 / 4),
        ('small', 8 / 9),
        ('medium', 1),
        ('large', 6 / 5),
        ('x-large', 3 / 2),
        ('xx-large', 2),
    )
}

# These are unspecified, other than 'thin' <= 'medium' <= 'thick'.
# Values are in pixels.
BORDER_WIDTH_KEYWORDS = {
    'thin': 1,
    'medium': 3,
    'thick': 5,
}
assert INITIAL_VALUES['border_top_width'] == BORDER_WIDTH_KEYWORDS['medium']

# https://www.w3.org/TR/CSS21/fonts.html#propdef-font-weight
FONT_WEIGHT_RELATIVE = {
    'bolder': {
        100: 400,
        200: 400,
        300: 400,
        400: 700,
        500: 700,
        600: 900,
        700: 900,
        800: 900,
        900: 900,
    },
    'lighter': {
        100: 100,
        200: 100,
        300: 100,
        400: 100,
        500: 100,
        600: 400,
        700: 400,
        800: 700,
        900: 700,
    },
}

# https://www.w3.org/TR/css-page-3/#size
PAGE_SIZES = {
    page_size: (Dimension(width, unit), Dimension(height, unit))
    for page_size, width, height, unit in (
        ('a10', 26, 37, 'mm'),
        ('a9', 37, 52, 'mm'),
        ('a8', 52, 74, 'mm'),
        ('a7', 74, 105, 'mm'),
        ('a6', 105, 148, 'mm'),
        ('a5', 148, 210, 'mm'),
        ('a4', 210, 297, 'mm'),
        ('a3', 297, 420, 'mm'),
        ('a2', 420, 594, 'mm'),
        ('a1', 594, 841, 'mm'),
        ('a0', 841, 1189, 'mm'),
        ('b10', 31, 44, 'mm'),
        ('b9', 44, 62, 'mm'),
        ('b8', 62, 88, 'mm'),
        ('b7', 88, 125, 'mm'),
        ('b6', 125, 176, 'mm'),
        ('b5', 176, 250, 'mm'),
        ('b4', 250, 353, 'mm'),
        ('b3', 353, 500, 'mm'),
        ('b2', 500, 707, 'mm'),
        ('b1', 707, 1000, 'mm'),
        ('b0', 1000, 1414, 'mm'),
        ('c10', 28, 40, 'mm'),
        ('c9', 40, 57, 'mm'),
        ('c8', 57, 81, 'mm'),
        ('c7', 81, 114, 'mm'),
        ('c6', 114, 162, 'mm'),
        ('c5', 162, 229, 'mm'),
        ('c4', 229, 324, 'mm'),
        ('c3', 324, 458, 'mm'),
        ('c2', 458, 648, 'mm'),
        ('c1', 648, 917, 'mm'),
        ('c0', 917, 1297, 'mm'),
        ('jis-b10', 32, 45, 'mm'),
        ('jis-b9', 45, 64, 'mm'),
        ('jis-b8', 64, 91, 'mm'),
        ('jis-b7', 91, 128, 'mm'),
        ('jis-b6', 128, 182, 'mm'),
        ('jis-b5', 182, 257, 'mm'),
        ('jis-b4', 257, 364, 'mm'),
        ('jis-b3', 364, 515, 'mm'),
        ('jis-b2', 515, 728, 'mm'),
        ('jis-b1', 728, 1030, 'mm'),
        ('jis-b0', 1030, 1456, 'mm'),
        ('letter', 8.5, 11, 'in'),
        ('legal', 8.5, 14, 'in'),
        ('ledger', 11, 17, 'in'),
    )
}
# In "portrait" orientation.
assert all(width.value < height.value for width, height in PAGE_SIZES.values())

INITIAL_PAGE_SIZE = PAGE_SIZES['a4']
INITIAL_VALUES['size'] = tuple(
    to_pixels(size, None, 'size') for size in INITIAL_PAGE_SIZE)


# Maps physical to functions getting block and inline directions.
PHYSICAL_FUNCTIONS = {}


def register_logical(names, prefixes=('',), suffixes=('',)):
    """Decorator registering logical properties matching physical ``names``."""

    def decorator(function):
        """Register the properties ``names`` for ``function``."""
        for name in names:
            name = name.replace('-', '_')
            for prefix in prefixes:
                for suffix in suffixes:
                    property_name = name
                    if prefix:
                        property_name = f'{prefix}_{property_name}'
                    if suffix:
                        property_name = f'{property_name}_{suffix}'
                    PHYSICAL_FUNCTIONS[property_name] = partial(
                        function, name=name, prefix=prefix, suffix=suffix)
        return function
    return decorator


@register_logical(('width', 'height'), prefixes=('', 'max', 'min'))
def physical_size(name, prefix, suffix, block, inline):
    vertical_main_direction = block in ('ttb', 'btt')
    vertical_property = 'height' in name
    logical = 'block' if (vertical_property == vertical_main_direction) else 'inline'
    return f'{prefix}_{logical}_size' if prefix else f'{logical}_size'


@register_logical(
    ('top', 'left', 'bottom', 'right'),
    prefixes=('', 'padding', 'margin'))
@register_logical(
    ('top', 'left', 'bottom', 'right'),
    prefixes=('border',), suffixes=('width', 'style', 'color'))
def physical_inset(name, prefix, suffix, block, inline):
    if name == 'top':
        logical = 'block' if block in ('ttb', 'btt') else 'inline'
        side = 'start' if 'ttb' in (block, inline) else 'end'
    elif name == 'bottom':
        logical = 'block' if block in ('ttb', 'btt') else 'inline'
        side = 'start' if 'btt' in (block, inline) else 'end'
    elif name == 'left':
        logical = 'block' if block in ('ltr', 'rtl') else 'inline'
        side = 'start' if 'ltr' in (block, inline) else 'end'
    elif name == 'right':
        logical = 'block' if block in ('ltr', 'rtl') else 'inline'
        side = 'start' if 'rtl' in (block, inline) else 'end'
    prefix = f'{prefix or "inset"}_'
    if suffix:
        suffix = f'_{suffix}'
    return f'{prefix}{logical}_{side}{suffix}'


@register_logical(
    ('top_left', 'top_right', 'bottom_left', 'bottom_right'),
    prefixes=('border',), suffixes=('radius',))
def physical_radius(name, prefix, suffix, block, inline):
    vertical, horizontal = name.split('_')
    if block == 'ttb':
        block = 'start' if vertical == 'top' else 'end'
    elif block == 'btt':
        block = 'start' if vertical == 'bottom' else 'end'
    elif block == 'ltr':
        block = 'start' if horizontal == 'left' else 'end'
    elif block == 'rtl':
        block = 'start' if horizontal == 'right' else 'end'
    if inline == 'ttb':
        inline = 'start' if vertical == 'top' else 'end'
    elif inline == 'btt':
        inline = 'start' if vertical == 'bottom' else 'end'
    elif inline == 'ltr':
        inline = 'start' if horizontal == 'left' else 'end'
    elif inline == 'rtl':
        inline = 'start' if horizontal == 'right' else 'end'
    return f'{prefix}_{block}_{inline}_{suffix}'


# Maps property names to functions returning the computed values
COMPUTER_FUNCTIONS = {}


def register_computer(name):
    """Decorator registering a property ``name`` for a function."""
    name = name.replace('-', '_')

    def decorator(function):
        """Register the property ``name`` for ``function``."""
        COMPUTER_FUNCTIONS[name] = function
        return function
    return decorator


@register_computer('background-image')
def background_image(style, name, values):
    """Compute lenghts in gradient background-image."""
    return tuple(image(style, name, value) for value in values)


@register_computer('border-image-source')
def image(style, name, image):
    """Compute lenghts in gradient border-image-source."""
    type_, value = image
    if type_ in ('linear-gradient', 'radial-gradient'):
        value.stop_positions = tuple(
            length(style, name, pos) if pos is not None else None
            for pos in value.stop_positions)
        value.color_hints = tuple(
            length(style, name, hint) if hint is not None else None
            for hint in value.color_hints)
    if type_ == 'radial-gradient':
        value.center, = compute_position(style, name, (value.center,))
        if value.size_type == 'explicit':
            value.size = length_or_percentage_tuple(style, name, value.size)
    return image


@register_computer('color')
@register_computer('background-color')
@register_computer('border-top-color')
@register_computer('border-right-color')
@register_computer('border-bottom-color')
@register_computer('border-left-color')
@register_computer('column-rule-color')
@register_computer('outline-color')
@register_computer('text-decoration-color')
def color(style, name, values):
    return parse_color(values, style['color_scheme'])


@register_computer('box-shadow')
def box_shadow(style, name, values):
    return tuple((
        length(style, name, x), length(style, name, y),
        length(style, name, blur), length(style, name, spread),
        parse_color(color, style['color_scheme']), inset,
    ) for x, y, blur, spread, color, inset in values)


@register_computer('background-position')
@register_computer('object-position')
def compute_position(style, name, values):
    """Compute lengths in background-position."""
    return tuple(
        (origin_x, length(style, name, pos_x),
         origin_y, length(style, name, pos_y))
        for origin_x, pos_x, origin_y, pos_y in values)


@register_computer('transform-origin')
def length_or_percentage_tuple(style, name, values):
    """Compute the lists of lengths that can be percentages."""
    return tuple(length(style, name, value) for value in values)


@register_computer('border-spacing')
@register_computer('size')
@register_computer('clip')
def length_tuple(style, name, values):
    """Compute the properties with a list of lengths."""
    return tuple(length(style, name, value, pixels_only=True) for value in values)


@register_computer('break-after')
@register_computer('break-before')
def break_before_after(style, name, value):
    """Compute the ``break-before`` and ``break-after`` properties."""
    return 'page' if value == 'always' else value


@register_computer('top')
@register_computer('right')
@register_computer('left')
@register_computer('bottom')
@register_computer('margin-top')
@register_computer('margin-right')
@register_computer('margin-bottom')
@register_computer('margin-left')
@register_computer('height')
@register_computer('width')
@register_computer('block-size')
@register_computer('inline-size')
@register_computer('min-width')
@register_computer('min-height')
@register_computer('min-block-size')
@register_computer('min-inline-size')
@register_computer('max-width')
@register_computer('max-height')
@register_computer('max-block-size')
@register_computer('max-inline-size')
@register_computer('padding-top')
@register_computer('padding-right')
@register_computer('padding-bottom')
@register_computer('padding-left')
@register_computer('text-indent')
@register_computer('hyphenate-limit-zone')
@register_computer('flex-basis')
@register_computer('text-underline-offset')
@register_computer('text-decoration-thickness')
def length(style, name, value, font_size=None, pixels_only=False):
    """Compute a length ``value``."""
    if value in ('auto', 'content', 'from-font') or check_math(value):
        return value
    elif value.value == 0:
        return 0 if pixels_only else ZERO_PIXELS
    elif value.unit not in LENGTH_UNITS:
        # A percentage or 'auto': no conversion needed.
        return value

    pixels = to_pixels(value, style, name, font_size)
    return pixels if pixels_only else Dimension(pixels, 'px')


@register_computer('bleed-left')
@register_computer('bleed-right')
@register_computer('bleed-top')
@register_computer('bleed-bottom')
def bleed(style, name, value):
    if value == 'auto':
        return Dimension(8 if 'crop' in style['marks'] else 0, 'px')
    return length(style, name, value)


@register_computer('letter-spacing')
def pixel_length(style, name, value):
    if value == 'normal':
        return value
    return length(style, name, value, pixels_only=True)


@register_computer('background-size')
def background_size(style, name, values):
    """Compute the ``background-size`` properties."""
    return tuple(
        value if value in ('contain', 'cover') else
        length_or_percentage_tuple(style, name, value)
        for value in values)


@register_computer('image-orientation')
def image_orientation(style, name, values):
    """Compute the ``image-orientation`` properties."""
    if values in ('none', 'from-image'):
        return values
    angle, flip = values
    return (round(angle / pi * 2) % 4 * 90, flip)


@register_computer('border-top-width')
@register_computer('border-right-width')
@register_computer('border-left-width')
@register_computer('border-bottom-width')
@register_computer('column-rule-width')
@register_computer('outline-width')
def border_width(style, name, value):
    """Compute the ``border-*-width`` properties."""
    border_style = style[name.replace('width', 'style')]
    if border_style in ('none', 'hidden'):
        return 0

    if value in BORDER_WIDTH_KEYWORDS:
        return BORDER_WIDTH_KEYWORDS[value]

    if isinstance(value, int):
        # The initial value can get here, but length() would fail as
        # it does not have a 'unit' attribute.
        return value

    return length(style, name, value, pixels_only=True)


@register_computer('border-image-slice')
@register_computer('mask-border-slice')
def border_image_slice(style, name, values):
    """Compute the ``border-image-slice`` property."""
    computed_values = []
    fill = None
    for value in values:
        if value == 'fill':
            fill = value
        else:
            number, unit = value
            if unit is None:
                computed_values.append(number)
            else:
                computed_values.append(Dimension(number, '%'))
    if len(computed_values) == 1:
        computed_values *= 4
    elif len(computed_values) == 2:
        computed_values *= 2
    elif len(computed_values) == 3:
        computed_values.append(computed_values[1])
    return (*computed_values, fill)


@register_computer('border-image-width')
@register_computer('mask-border-width')
def border_image_width(style, name, values):
    """Compute the ``border-image-width`` property."""
    computed_values = []
    for value in values:
        if value == 'auto':
            computed_values.append(value)
        else:
            number, unit = value
            computed_values.append(number if unit is None else value)
    if len(computed_values) == 1:
        computed_values *= 4
    elif len(computed_values) == 2:
        computed_values *= 2
    elif len(computed_values) == 3:
        computed_values.append(computed_values[1])
    return tuple(computed_values)


@register_computer('border-image-outset')
@register_computer('mask-border-outset')
def border_image_outset(style, name, values):
    """Compute the ``border-image-outset`` property."""
    computed_values = [
        value if isinstance(value, (int, float)) else length(style, name, value)
        for value in values]
    if len(computed_values) == 1:
        computed_values *= 4
    elif len(computed_values) == 2:
        computed_values *= 2
    elif len(computed_values) == 3:
        computed_values.append(computed_values[1])
    return tuple(computed_values)


@register_computer('border-image-repeat')
@register_computer('mask-border-repeat')
def border_image_repeat(style, name, values):
    """Compute the ``border-image-repeat`` property."""
    return (values * 2) if len(values) == 1 else values


@register_computer('column-width')
@register_computer('outline-offset')
def length_pixels_only(style, name, value):
    """Compute a pixel length property."""
    return length(style, name, value, pixels_only=True)


@register_computer('border-top-left-radius')
@register_computer('border-top-right-radius')
@register_computer('border-bottom-left-radius')
@register_computer('border-bottom-right-radius')
def border_radius(style, name, values):
    """Compute the ``border-*-radius`` properties."""
    return tuple(length(style, name, value) for value in values)


@register_computer('column-gap')
@register_computer('row-gap')
def gap(style, name, value):
    """Compute the ``*-gap`` properties."""
    return value if value == 'normal' else length(style, name, value)


def _content_list(style, values):
    computed_values = []
    for value in values:
        if value[0] in (
                'string', 'content', 'url', 'quote', 'leader()',
                'counter()', 'counters()', 'content()', 'element()', 'string()',
                'attr()', 'target-counter()', 'target-counters()', 'target-text()'):
            computed_values.append(value)
        else:
            LOGGER.warning('Unable to compute content: %s', value)
    return tuple(computed_values)


@register_computer('bookmark-label')
def bookmark_label(style, name, values):
    """Compute the ``bookmark-label`` property."""
    return _content_list(style, values)


@register_computer('string-set')
def string_set(style, name, values):
    """Compute the ``string-set`` property."""
    # Spec asks for strings after custom keywords, but we allow content-lists
    return tuple(
        (string_set[0], _content_list(style, string_set[1]))
        for string_set in values)


@register_computer('content')
def content(style, name, values):
    """Compute the ``content`` property."""
    if len(values) == 1:
        value, = values
        if value == 'normal':
            return 'inhibit' if style.pseudo_type else 'contents'
        elif value == 'none':
            return 'inhibit'
    return _content_list(style, values)


@register_computer('display')
def display(style, name, value):
    """Compute the ``display`` property."""
    # See https://www.w3.org/TR/CSS21/visuren.html#dis-pos-flo.
    float_ = style.specified['float']
    position = style.specified['position']
    if position in ('absolute', 'fixed') or float_ != 'none' or style.is_root_element:
        if value == ('inline-table',):
            return ('block', 'table')
        elif len(value) == 1 and value[0].startswith('table-'):
            return ('block', 'flow')
        elif value[0] == 'inline':
            if 'list-item' in value:
                return ('block', 'flow', 'list-item')
            else:
                return ('block', 'flow')
    return value


@register_computer('float')
def compute_float(style, name, value):
    """Compute the ``float`` property."""
    # See https://www.w3.org/TR/CSS21/visuren.html#dis-pos-flo.
    position = style.specified['position']
    if position in ('absolute', 'fixed') or position[0] in ('running()', 'note()'):
        return 'none'
    else:
        return value


@register_computer('font-size')
def font_size(style, name, value):
    """Compute the ``font-size`` property."""
    if value in FONT_SIZE_KEYWORDS:
        return FONT_SIZE_KEYWORDS[value]

    keyword_values = list(FONT_SIZE_KEYWORDS.values())
    if style.parent_style is None:
        parent_font_size = INITIAL_VALUES['font_size']
    else:
        parent_font_size = style.parent_style['font_size']

    if value == 'larger':
        for i, keyword_value in enumerate(keyword_values):
            if keyword_value > parent_font_size:
                return keyword_values[i]
        else:
            return parent_font_size * 1.2
    elif value == 'smaller':
        for i, keyword_value in enumerate(keyword_values[::-1]):
            if keyword_value < parent_font_size:
                return keyword_values[-i - 1]
        else:
            return parent_font_size * 0.8
    elif isinstance(value, Dimension) and value.unit == '%':
        return value.value * parent_font_size / 100
    else:
        return length(
            style, name, value, pixels_only=True,
            font_size=parent_font_size)


@register_computer('font-weight')
def font_weight(style, name, value):
    """Compute the ``font-weight`` property."""
    if value == 'normal':
        return 400
    elif value == 'bold':
        return 700
    elif value in ('bolder', 'lighter'):
        if style.parent_style is None:
            parent_value = INITIAL_VALUES['font_weight']
        else:
            parent_value = style.parent_style['font_weight']
        return FONT_WEIGHT_RELATIVE[value][parent_value]
    else:
        return value


def _compute_track_breadth(style, name, value):
    """Compute track breadth."""
    if value in ('auto', 'min-content', 'max-content'):
        return value
    elif isinstance(value, Dimension):
        if value.unit and value.unit.lower() == 'fr':
            return value
        else:
            return length(style, name, value)


def _track_size(style, name, values):
    """Compute track size."""
    return_values = []
    for i, value in enumerate(values):
        if i % 2 == 0:
            # line name
            return_values.append(value)
        else:
            # track section
            track_breadth = _compute_track_breadth(style, name, value)
            if track_breadth:
                return_values.append(track_breadth)
            elif value[0] == 'minmax()':
                return_values.append((
                    'minmax()',
                    _compute_track_breadth(style, name, value[1]),
                    _compute_track_breadth(style, name, value[2])))
            elif value[0] == 'fit-content()':
                return_values.append((
                    'fit-content()', length(style, name, value[1])))
            elif value[0] == 'repeat()':
                return_values.append((
                    'repeat()', value[1], _track_size(style, name, value[2])))
    return tuple(return_values)


@register_computer('grid-template-columns')
@register_computer('grid-template-rows')
def grid_template(style, name, values):
    """Compute the ``grid-template-*`` properties."""
    if values == 'none' or values[0] == 'subgrid':
        return values
    else:
        return _track_size(style, name, values)


@register_computer('grid-auto-columns')
@register_computer('grid-auto-rows')
def grid_auto(style, name, values):
    """Compute the ``grid-auto-*`` properties."""
    return_values = []
    for value in values:
        track_breadth = _compute_track_breadth(style, name, value)
        if track_breadth:
            return_values.append(track_breadth)
        elif value[0] == 'minmax()':
            return_values.append((
                'minmax()', grid_auto(style, name, [value[1]])[0],
                grid_auto(style, name, [value[2]])[0]))
        elif value[0] == 'fit-content()':
            return_values.append((
                'fit-content()', grid_auto(style, name, [value[1]])[0]))
    return tuple(return_values)


@register_computer('line-height')
def line_height(style, name, value):
    """Compute the ``line-height`` property."""
    if value == 'normal':
        return value
    elif check_math(value):
        return value
    elif not value.unit:
        return value.value
    elif value.unit == '%':
        factor = value.value / 100
        font_size_value = style['font_size']
        pixels = factor * font_size_value
        return Dimension(pixels, 'px')
    else:
        return length(style, name, value)


@register_computer('lang')
def lang(style, name, values):
    """Compute the ``lang`` property."""
    name, value = values
    if name == 'string':
        return value


@register_computer('tab-size')
def tab_size(style, name, value):
    """Compute the ``tab-size`` property."""
    return value if isinstance(value, int) else length(style, name, value)


@register_computer('transform')
def transform(style, name, value):
    """Compute the ``transform`` property."""
    result = []
    for function, args in value:
        if function == 'translate':
            args = length_or_percentage_tuple(style, name, args)
        result.append((function, args))
    return tuple(result)


@register_computer('vertical-align')
def vertical_align(style, name, value):
    """Compute the ``vertical-align`` property."""
    # Use +/- half an em for super and sub, same as Pango.
    # (See the SUPERSUB_RISE constant in pango-markup.c)
    if value in ('baseline', 'middle', 'text-top', 'text-bottom', 'top', 'bottom'):
        return value
    elif value == 'super':
        return style['font_size'] * 0.5
    elif value == 'sub':
        return style['font_size'] * -0.5
    elif check_math(value):
        return value
    elif value.unit == '%':
        height, _ = strut(style)
        return height * value.value / 100
    else:
        return length(style, name, value, pixels_only=True)


@register_computer('word-spacing')
def word_spacing(style, name, value):
    """Compute the ``word-spacing`` property."""
    return 0 if value == 'normal' else length(style, name, value, pixels_only=True)
